package com.exampledi.demodi;

// CustomerRepository.java
public interface CustomerRepository {
    void save(Customer customer);
}
