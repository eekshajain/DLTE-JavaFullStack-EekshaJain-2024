package com.exampledi.demodi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemodiApplicationTests {

    @Test
    void contextLoads() {
    }

}
